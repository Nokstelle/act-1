STOCKWISE - INVENTORY MANAGEMENT UI

REQUIREMENTS
- Visual Studio Code
- A modern web browser
- Optional: VS Code Live Server extension

RUN
1. Extract the ZIP file.
2. Open the extracted inventory-management-system folder in VS Code.
3. Open index.html.
4. Right-click inside the editor and choose "Open with Live Server" if installed.
   Or double-click index.html in File Explorer to open it in your browser.

FILES
- index.html: page structure
- style.css: layout and styling
- script.js: frontend CRUD logic and LocalStorage

NOTE
This is a frontend-only demo. LocalStorage saves records in the current browser.
It is not a real database and does not include authentication, a server, or multi-user access.
