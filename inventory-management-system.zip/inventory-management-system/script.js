const STORAGE_KEY = "stockwise-products-v1";
const starterProducts = [
  {id:1,name:"Wireless Mouse",sku:"ACC-001",category:"Accessories",quantity:24,price:599},
  {id:2,name:"Mechanical Keyboard",sku:"ACC-002",category:"Accessories",quantity:4,price:1850},
  {id:3,name:"Laptop Stand",sku:"OFF-001",category:"Office Supplies",quantity:12,price:950},
  {id:4,name:"USB-C Hub",sku:"ELE-001",category:"Electronics",quantity:0,price:1299},
  {id:5,name:"Desk Lamp",sku:"OFF-002",category:"Office Supplies",quantity:18,price:780},
  {id:6,name:"Monitor 24-inch",sku:"ELE-002",category:"Electronics",quantity:7,price:6499}
];

let products = loadProducts();
const $ = (id) => document.getElementById(id);

function loadProducts() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [...starterProducts];
  } catch (error) {
    console.error("Could not load saved products:", error);
    return [...starterProducts];
  }
}
function saveProducts() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
}
function money(value) {
  return new Intl.NumberFormat("en-PH", {style:"currency", currency:"PHP"}).format(value);
}
function stockStatus(quantity) {
  if (quantity === 0) return "Out of stock";
  if (quantity <= 5) return "Low stock";
  return "In stock";
}
function statusClass(status) {
  return status === "In stock" ? "in" : status === "Low stock" ? "low" : "out";
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function renderStats() {
  $("stat-products").textContent = products.length;
  $("stat-units").textContent = products.reduce((sum,p) => sum + p.quantity, 0).toLocaleString("en-PH");
  $("stat-value").textContent = money(products.reduce((sum,p) => sum + p.quantity * p.price, 0));
  $("stat-low").textContent = products.filter(p => p.quantity > 0 && p.quantity <= 5).length;
}
function productRows(items, includeActions) {
  if (!items.length) return `<tr><td colspan="${includeActions ? 7 : 5}" class="empty-state">No products found. Add a product to get started.</td></tr>`;
  return items.map(p => {
    const status = stockStatus(p.quantity);
    const name = escapeHTML(p.name);
    return `<tr>
      <td><div class="product-cell"><span class="product-thumb">${name.charAt(0).toUpperCase()}</span><span>${name}</span></div></td>
      ${includeActions ? `<td class="sku">${escapeHTML(p.sku)}</td>` : ""}
      <td>${escapeHTML(p.category)}</td>
      <td>${p.quantity}</td>
      <td>${money(p.price)}</td>
      <td><span class="pill ${statusClass(status)}">${status}</span></td>
      ${includeActions ? `<td><button class="action-btn" data-action="edit" data-id="${p.id}">Edit</button><button class="action-btn delete" data-action="delete" data-id="${p.id}">Delete</button></td>` : ""}
    </tr>`;
  }).join("");
}
function renderTables() {
  const recent = [...products].sort((a,b) => b.id - a.id).slice(0,5);
  $("recent-table").innerHTML = productRows(recent, false);
  const search = $("search-input").value.trim().toLowerCase();
  const category = $("category-filter").value;
  const status = $("status-filter").value;
  const filtered = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search) || p.sku.toLowerCase().includes(search);
    const matchesCategory = category === "all" || p.category === category;
    const matchesStatus = status === "all" || stockStatus(p.quantity) === status;
    return matchesSearch && matchesCategory && matchesStatus;
  });
  $("products-table").innerHTML = productRows(filtered, true);
  $("result-count").textContent = `${filtered.length} product${filtered.length === 1 ? "" : "s"}`;
}
function renderAll() {
  renderStats();
  renderTables();
  renderCategoryOptions();
}
function renderCategoryOptions() {
  const select = $("category-filter");
  const current = select.value || "all";
  const categories = [...new Set(products.map(p => p.category))].sort();
  select.innerHTML = `<option value="all">All categories</option>` + categories.map(c => `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join("");
  select.value = categories.includes(current) ? current : "all";
}
function showView(view) {
  $("dashboard-view").classList.toggle("hidden", view !== "dashboard");
  $("products-view").classList.toggle("hidden", view !== "products");
  $("page-title").textContent = view === "dashboard" ? "Dashboard" : "Products";
  document.querySelectorAll(".nav-item").forEach(btn => btn.classList.toggle("active", btn.dataset.view === view));
  if (view === "products") renderTables();
}
function openModal(product = null) {
  $("product-form").reset();
  $("form-error").textContent = "";
  $("product-id").value = product ? product.id : "";
  $("modal-title").textContent = product ? "Edit product" : "Add new product";
  if (product) {
    $("product-name").value = product.name;
    $("product-sku").value = product.sku;
    $("product-category").value = product.category;
    $("product-quantity").value = product.quantity;
    $("product-price").value = product.price;
  }
  $("product-modal").classList.remove("hidden");
  $("product-name").focus();
}
function closeModal() {
  $("product-modal").classList.add("hidden");
}
function handleSubmit(event) {
  event.preventDefault();
  const id = $("product-id").value;
  const name = $("product-name").value.trim();
  const sku = $("product-sku").value.trim().toUpperCase();
  const category = $("product-category").value;
  const quantity = Number($("product-quantity").value);
  const price = Number($("product-price").value);
  if (!name || !sku || !category || !Number.isInteger(quantity) || quantity < 0 || !Number.isFinite(price) || price < 0) {
    $("form-error").textContent = "Please enter valid product details. Quantity must be a whole number of 0 or more.";
    return;
  }
  const duplicate = products.some(p => p.sku.toLowerCase() === sku.toLowerCase() && String(p.id) !== id);
  if (duplicate) {
    $("form-error").textContent = "That SKU already exists. Please use a unique SKU.";
    return;
  }
  const record = {id: id ? Number(id) : Date.now(), name, sku, category, quantity, price};
  if (id) products = products.map(p => p.id === Number(id) ? record : p);
  else products.unshift(record);
  saveProducts();
  renderAll();
  closeModal();
}
function handleTableAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const id = Number(button.dataset.id);
  const product = products.find(p => p.id === id);
  if (!product) return;
  if (button.dataset.action === "edit") openModal(product);
  if (button.dataset.action === "delete") {
    if (confirm(`Delete "${product.name}" from your inventory?`)) {
      products = products.filter(p => p.id !== id);
      saveProducts();
      renderAll();
    }
  }
}

document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => showView(btn.dataset.view)));
$("top-add-btn").addEventListener("click", () => openModal());
$("products-add-btn").addEventListener("click", () => openModal());
$("view-all-btn").addEventListener("click", () => showView("products"));
$("close-modal").addEventListener("click", closeModal);
$("cancel-modal").addEventListener("click", closeModal);
$("product-modal").addEventListener("click", event => { if (event.target === $("product-modal")) closeModal(); });
$("product-form").addEventListener("submit", handleSubmit);
$("products-table").addEventListener("click", handleTableAction);
$("search-input").addEventListener("input", renderTables);
$("category-filter").addEventListener("change", renderTables);
$("status-filter").addEventListener("change", renderTables);
$("reset-demo-btn").addEventListener("click", () => {
  if (confirm("Reset all products to the original demo data? Your current browser data will be replaced.")) {
    products = [...starterProducts];
    saveProducts();
    renderAll();
  }
});
$("today-date").textContent = new Intl.DateTimeFormat("en-PH", {dateStyle:"medium"}).format(new Date());
renderAll();
